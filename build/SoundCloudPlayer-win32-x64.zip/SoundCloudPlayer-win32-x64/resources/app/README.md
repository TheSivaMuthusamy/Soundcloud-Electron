# Soundcloud Electron Player

An electron based Soundcloud player. Built with a different setup compared to past projects and browserfy instead of webpack. The player can search through Soundcloud's library and has an autocomplete feature. One can also seek through the songs by clicking on the progress bar.

---

###  Installation

- `npm install`
- `npm run start`

---

Builds have also been added if you don't want to install. Just choose the correct build for your OS in the build folder.